package name.vaccari.matteo.paste;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;


public class OutputFileTest {

	private static final String TMP_FILE_VUOTO = "/tmp/file-vuoto.txt";
	private static final String TMP_FILE_NON_VUOTO = "/tmp/file-non-vuoto.txt";

	@Test
	public void createEmptyFile() throws Exception {
		new File(TMP_FILE_VUOTO).delete();
		assertFalse("inizialmente il file non c'e'", fileExists(TMP_FILE_VUOTO));		
		IOutputFile outputFile = new OutputFile(TMP_FILE_VUOTO);
		
		outputFile.close();
		
		assertTrue("non ha creato il file", fileExists(TMP_FILE_VUOTO));
	}
	
	@Test
	public void appendLinesToFile() throws Exception {
		IOutputFile outputFile = new OutputFile(TMP_FILE_NON_VUOTO);
		
		outputFile.writeLine("bla");
		outputFile.writeLine("ciao");
		outputFile.close();
		
		assertFileContains(Arrays.asList("bla", "ciao"), TMP_FILE_NON_VUOTO);
	}

	private void assertFileContains(List<String> lines, String fileName) throws Exception {
		IInputFile inputFile = new InputFile(fileName);
		for (String line : lines) {
			assertEquals(line, inputFile.readLine());
		}
		assertEquals(null, inputFile.readLine());
	}

	private boolean fileExists(String fileName) {
		return new File(fileName).exists();
	}
}
