package name.vaccari.matteo.paste;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;


public class PasteTest {
	
	public class InMemoryInputFile implements IInputFile {

		private final String[] lines;
		private int nextLine;

		public InMemoryInputFile(String ... lines) {
			this.lines = lines;
		}

		public String readLine() throws IOException {
			if (nextLine == lines.length) {
				return null;
			}
			return lines[nextLine++];
		}

	}

	public class InMemoryOutputFile implements IOutputFile {
		public List<String> lines = new ArrayList<String>();
		
		public void writeLine(String line) throws IOException {
			lines.add(line);
		}

		public void close() throws IOException {
		}
	}

	public class EmptyFile implements IInputFile {
		public String readLine() throws IOException {
			return null;
		}
	}

	@Test
	public void testname() throws Exception {
		InMemoryOutputFile outputFile = new InMemoryOutputFile();
		IInputFile inputFile0 = new EmptyFile();
		IInputFile inputFile1 = new EmptyFile();
		PasteService service = new PasteService(inputFile0, inputFile1, outputFile);
		
		service.execute();
		
		assertEquals(emptyList(), outputFile.lines);
	}

	@Test
	public void pasteOneLine() throws Exception {
		InMemoryOutputFile outputFile = new InMemoryOutputFile();
		IInputFile inputFile0 = new InMemoryInputFile("aaa");
		IInputFile inputFile1 = new InMemoryInputFile("bbb");
		PasteService service = new PasteService(inputFile0, inputFile1, outputFile);
		
		service.execute();
		
		assertEquals(Arrays.asList("aaabbb"), outputFile.lines);
	}


	
	private List<String> emptyList() {
		return Arrays.asList();
	}
}
