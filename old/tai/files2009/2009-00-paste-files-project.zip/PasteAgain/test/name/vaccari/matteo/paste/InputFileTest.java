package name.vaccari.matteo.paste;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class InputFileTest {
	@Test
	public void inputFileShouldReturnNoLinesForEmptyFile() throws Exception {
		IInputFile inputFile = new InputFile("/dev/null");		
		assertEquals(null, inputFile.readLine());
	}

	@Test
	public void inputFileShouldReturnEachLineFromTheFile() throws Exception {
		IInputFile inputFile = new InputFile("test/test-file.txt");		
		assertEquals("uno", inputFile.readLine());
		assertEquals("due", inputFile.readLine());
		assertEquals("tre", inputFile.readLine());
		assertEquals(null, inputFile.readLine());
	}
}
