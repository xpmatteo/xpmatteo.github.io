package name.vaccari.matteo.paste;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class OutputFile implements IOutputFile {

	private String fileName;
	private BufferedWriter writer;

	public OutputFile(String fileName) {
		this.fileName = fileName;
	}

	public void close() throws IOException {
		if (null == writer) {
			new File(this.fileName).createNewFile();
		} else {
			writer.close();
		}
	}

	public void writeLine(String line) throws IOException {
		if (null == writer) {
			writer = new BufferedWriter(new FileWriter(fileName));
		}
		writer.append(line);
		writer.newLine();
	}

}
