package name.vaccari.matteo.paste;

import java.io.IOException;

public class PasteService {

	private final IInputFile inputFile0;
	private final IInputFile inputFile1;
	private final IOutputFile outputFile;

	public PasteService(IInputFile inputFile0, IInputFile inputFile1,
			IOutputFile outputFile) {
				this.inputFile0 = inputFile0;
				this.inputFile1 = inputFile1;
				this.outputFile = outputFile;
	}

	public void execute() throws IOException {
		String lineFromFirst = inputFile0.readLine();
		String lineFromSecond = inputFile1.readLine();
		if (null != lineFromFirst) { 
			String concatenatedLine = lineFromFirst + lineFromSecond;
			outputFile.writeLine(concatenatedLine);
		}
	}

}
