package name.vaccari.matteo.paste;

import java.io.IOException;

public class PasteMain {
	
	public static void main(String[] args) throws IOException {
		InputFile first = new InputFile(args[0]);
		InputFile second = new InputFile(args[1]);
		OutputFile outputFile = new OutputFile(args[2]);
		
		PasteService pasteService = new PasteService(first, second, outputFile);
		
		pasteService.execute();
	}

}
