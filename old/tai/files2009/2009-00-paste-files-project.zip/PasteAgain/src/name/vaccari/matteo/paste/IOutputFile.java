package name.vaccari.matteo.paste;

import java.io.IOException;

public interface IOutputFile {

	void close() throws IOException;

	void writeLine(String line) throws IOException;

}