package name.vaccari.matteo.paste;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class InputFile implements IInputFile {

	private final String fileName;
	private BufferedReader reader;

	public InputFile(String fileName) {
		this.fileName = fileName;
	}

	public String readLine() throws IOException {
		if (null == reader) {
			reader = new BufferedReader(new FileReader(fileName));
		}
		return reader.readLine();
	}

}
