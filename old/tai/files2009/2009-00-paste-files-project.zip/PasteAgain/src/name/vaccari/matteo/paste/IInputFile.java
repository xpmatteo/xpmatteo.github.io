package name.vaccari.matteo.paste;

import java.io.IOException;

public interface IInputFile {

	String readLine() throws IOException;

}