
#include <cgreen/cgreen.h>

extern TestSuite *test_read_command_suite(void);
extern TestSuite *test_wait_suite(void);

int main() {
  TestSuite *suite = create_test_suite();
  add_suite(suite, test_read_command_suite());
  add_suite(suite, test_wait_suite());
  return run_test_suite(suite, create_text_reporter());
}
