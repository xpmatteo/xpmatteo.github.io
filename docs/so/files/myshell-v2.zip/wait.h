
void wait_for_terminated_children(void);
void report_child_terminated(pid_t child, int status);

typedef pid_t (*waitpid_function_t)(pid_t wpid, int *status, int options);
extern waitpid_function_t the_waitpid_function;

typedef void (*child_reporting_function_t)(pid_t terminated_child, int status);
extern child_reporting_function_t the_child_reporting_function;
