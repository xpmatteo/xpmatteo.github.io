
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>

#include "wait.h"

waitpid_function_t the_waitpid_function = waitpid;
child_reporting_function_t the_child_reporting_function = report_child_terminated;

void wait_for_terminated_children(void) {
  int status, pid;
  while ((pid = the_waitpid_function(-1, &status, WNOHANG)) > 0) {
    the_child_reporting_function(pid, status);
  }
}

void report_child_terminated(pid_t child, int status) {
  printf("child %d terminated with status %d\n", child, status);
}


