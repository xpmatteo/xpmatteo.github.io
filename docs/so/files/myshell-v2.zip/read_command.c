
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "read_command.h"

#define MAX_LINE 1024
#define MAX_TOKENS 10

char line[MAX_LINE];
char *tokens[MAX_TOKENS];
int num_tokens;

void chop_newline_at_end(char *s) {
  s[strlen(s)-1] = '\0';
}

void read_command() {
  char * read = fgets(line, MAX_LINE, stdin);
  if (!read) exit(0);
  chop_newline_at_end(line);
}

void tokenize_command() {
  num_tokens = 0;
  tokens[0] = strtok(line, " ");
  if (NULL == tokens[0]) {
    return;
  }
  num_tokens = 1;
  while (NULL != (tokens[num_tokens] = strtok(NULL, " "))) {
    num_tokens++;
  }
}

int command_is_in_foreground() {
  return 0 != strcmp("&", tokens[num_tokens-1]);
}
