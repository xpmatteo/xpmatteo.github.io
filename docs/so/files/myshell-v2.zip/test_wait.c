
#include <cgreen/cgreen.h>
#include "wait.h"

// stub che simula il comportamento di waitpid(2) quando non ci sono processi
// figli terminati
static int num_of_calls_to_waitpid = 0;
static pid_t always_no_children_exited(pid_t wpid, int *status, int options) {
  num_of_calls_to_waitpid++;
  assert_equal_with_message(-1, wpid, "mi aspetto wpid == -1");
  assert_equal_with_message(WNOHANG, options, "mi aspetto options == WNOHANG");
  assert_not_equal_with_message(NULL, status, "mi aspetto *status non null");
  return 0;
}

// stub che simula il comportamento di waitpid(2) quando c'è esattamente
// un processo figlio terminato
static pid_t one_child_exited(pid_t wpid, int *status, int options) {
  num_of_calls_to_waitpid++;
  if (num_of_calls_to_waitpid == 2) {
    return 0;
  } else {
    return 1234;
  }
  return 0;
}

// stub che simula la chiamata alla funzione che stampa una messaggio per
// ogni processo figlio terminato
static int num_of_calls_to_report_function = 0;
static void stub_report_children_exited(pid_t child, int status) {
  num_of_calls_to_report_function++;
}

void test_wait_when_no_children_exited() {
  the_waitpid_function = always_no_children_exited;
  the_child_reporting_function = stub_report_children_exited;

  wait_for_terminated_children();

  assert_equal(0, num_of_calls_to_report_function);
  assert_equal(1, num_of_calls_to_waitpid);
}

void test_wait_when_one_child_exited() {
  the_waitpid_function = one_child_exited;
  the_child_reporting_function = stub_report_children_exited;

  wait_for_terminated_children();

  assert_equal(1, num_of_calls_to_report_function);
  assert_equal(2, num_of_calls_to_waitpid);
}



TestSuite* test_wait_suite() {
  TestSuite *result = create_test_suite();
  add_test(result, test_wait_when_no_children_exited);
  add_test(result, test_wait_when_one_child_exited);
  return result;
}