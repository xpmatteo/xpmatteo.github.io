
#include <cgreen/cgreen.h>
#include <string.h>
#include <stdio.h>

#include "read_command.h"

void test_one_word() {
  sprintf(line, "pippo");
  tokenize_command();
  assert_equal(1, num_tokens);
  assert_string_equal("pippo", tokens[0]);
  assert_equal(NULL, tokens[1]);
}

void test_two_words() {
  sprintf(line, "pippo pluto");
  tokenize_command();
  assert_equal(2, num_tokens);
  assert_string_equal("pippo", tokens[0]);
  assert_string_equal("pluto", tokens[1]);
  assert_equal(NULL, tokens[2]);
}

void test_empty_line() {
	num_tokens = 999;
  strcpy(line, "");
  tokenize_command();
  assert_equal(0, num_tokens);
}

void test_in_foreground_if_last_token_is_ampersand() {
  sprintf(line, "sleep 10");
  tokenize_command();
  assert_true(command_is_in_foreground());

  sprintf(line, "sleep 10 &");
  tokenize_command();
  assert_false(command_is_in_foreground());
}


// TODO test_more_than_one_blank

TestSuite* test_read_command_suite() {
	TestSuite *result = create_test_suite();
	add_test(result, test_one_word);
	add_test(result, test_two_words);
	add_test(result, test_empty_line);
	add_test(result, test_in_foreground_if_last_token_is_ampersand);
	return result;
}
