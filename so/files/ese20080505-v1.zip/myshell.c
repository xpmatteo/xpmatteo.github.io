
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

#include "read_command.h"

void print_prompt() {
  printf("myshell> ");
}

void execute_command() {
  execlp(line, line, NULL);
  // se siamo qui la execlp ha fallito!
  perror(line);
}

void wait_for_child() {
  int status;
  wait(&status);
  printf("child returned with status %d\n", status);
}


int main() {
  while (1) {
    print_prompt();
    read_command();
    pid_t pid = fork();
    if (0 == pid) {
      execute_command();
    } else {
      wait_for_child();
    }
  }
}
