
#include <assert.h>
#include <string.h>
#include <stdio.h>

#include "read_command.h"

void test_one_word() {
  sprintf(line, "pippo");
  tokenize_command();
  assert(1 == num_tokens);
  assert(0 == strcmp("pippo", tokens[0]));
}

void test_two_words() {
  sprintf(line, "pippo pluto");
  tokenize_command();
  assert(2 == num_tokens);
  assert(0 == strcmp("pippo", tokens[0]));
  assert(0 == strcmp("pluto", tokens[1]));
}

void test_five_words() {
  sprintf(line, "foo bar baz pippo uffa");
  tokenize_command();
  assert(5 == num_tokens);
  assert(0 == strcmp("foo", tokens[0]));
  assert(0 == strcmp("uffa", tokens[4]));
}

// test_empty_line
// test_more_than_one_blank
// test_two_words
  

int main() {
    test_one_word();
    test_two_words();
    test_five_words();
    printf("OK!!\n");
}
