
extern char line[];
extern int num_tokens;
extern char *tokens[];


void read_command(void);
void tokenize_command(void);


